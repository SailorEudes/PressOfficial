<?php $__env->startSection('content'); ?>


<div class="relative px-8 pt-8 pb-20 mx-auto xl:px-5 max-w-7xl sm:px-6 lg:pt-10 lg:pb-28">
    <div class="absolute inset-0">
        <div class="bg-white h-1/3 sm:h-2/3"></div>
    </div>
    <div class="relative mx-auto max-w-7xl">
        <div class="flex flex-col justify-start">
            <h1 class="bg-clip-text bg-gradient-to-r from-yellow-400 via-red-400 to-purple-500 text-transparent text-3xl font-extrabold leading-9 tracking-tight sm:text-4xl sm:leading-10">
                Our Awesome Blog
            </h1>
            <p class="mt-3 text-xl leading-7 text-gray-500 sm:mt-4">
                Check out some of our latest blog posts below.
            </p>
            <ul class="flex self-start inline w-auto px-3 py-1 mt-3 text-xs font-medium text-white bg-gradient-to-r from-yellow-400 via-red-400 to-purple-500 rounded-md">
                <li class="mr-4 font-bold text-white uppercase">Categories:</li>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="<?php if(isset($category) && isset($category->slug) && ($category->slug == $cat->slug)): ?><?php echo e('text-blue-700'); ?><?php endif; ?>"><a href="<?php echo e(route('wave.blog.category', $cat->slug)); ?>"><?php echo e($cat->name); ?></a></li>
                <?php if(!$loop->last): ?>
                <li class="mx-2">&middot;</li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="grid gap-5 mx-auto mt-12 sm:grid-cols-2 lg:grid-cols-3">

            <!-- Loop Through Posts Here -->
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article id="post-<?php echo e($post->id); ?>" class="flex flex-col overflow-hidden rounded-lg shadow-lg" typeof="Article">

                <meta property="name" content="<?php echo e($post->title); ?>">
                <meta property="author" typeof="Person" content="admin">
                <meta property="dateModified" content="<?php echo e(Carbon\Carbon::parse($post->updated_at)->toIso8601String()); ?>">
                <meta class="uk-margin-remove-adjacent" property="datePublished" content="<?php echo e(Carbon\Carbon::parse($post->created_at)->toIso8601String()); ?>">

                <div class="flex-shrink-0">
                    <a href="<?php echo e($post->link()); ?>">
                        <img class="object-cover w-full h-48" src="<?php echo e($post->image()); ?>" alt="">
                    </a>
                </div>
                <div class="relative flex flex-col justify-between flex-1 p-6 bg-white">
                    <div class="flex-1">
                        <a href="<?php echo e($post->link()); ?>" class="block">
                            <h3 class="mt-2 text-xl font-semibold leading-7 text-gray-900">
                                <?php echo e($post->title); ?>

                            </h3>
                        </a>
                        <a href="<?php echo e($post->link()); ?>" class="block">
                            <p class="mt-3 text-base leading-6 text-gray-500">
                                <?php echo e(substr(strip_tags($post->body), 0, 200)); ?><?php if(strlen(strip_tags($post->body)) > 200): ?><?php echo e('...'); ?><?php endif; ?>
                            </p>
                        </a>
                    </div>
                    <p class="relative self-start inline-block px-2 py-1 mt-4 text-xs font-medium leading-5 text-gray-400 uppercase bg-gray-100 rounded">
                        <a href="<?php echo e(route('wave.blog.category', $post->category->slug)); ?>" class="text-gray-700 hover:underline" rel="category">
                            <?php echo e($post->category->name); ?>

                        </a>
                    </p>
                </div>

                <div class="flex items-center p-6 bg-gray-50">
                    <div class="flex-shrink-0">
                        <a href="#">
                            <img class="w-10 h-10 rounded-full" src="<?php echo e($post->user->avatar()); ?>" alt="">
                        </a>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium leading-5 text-gray-900">
                            Written by <a href="#" class="hover:underline"><?php echo e($post->user->name); ?></a>
                        </p>
                        <div class="flex text-sm leading-5 text-gray-500">
                            on <time datetime="<?php echo e(Carbon\Carbon::parse($post->created_at)->toIso8601String()); ?>" class="ml-1"><?php echo e(Carbon\Carbon::parse($post->created_at)->toFormattedDateString()); ?></time>
                        </div>
                    </div>
                </div>

            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End Post Loop Here -->

        </div>
    </div>

    <div class="flex justify-center my-10">
        <?php echo e($posts->links('theme::partials.pagination')); ?>

        <!--li class="uk-active"><span aria-current="page" class="page-numbers current">1</span></li>
		<li><a class="page-numbers" href="https://demo.yootheme.com/themes/wordpress/2017/copper-hill/?paged=2&amp;page_id=92">2</a></li>
		<li><a class="next page-numbers" href="https://demo.yootheme.com/themes/wordpress/2017/copper-hill/?paged=2&amp;page_id=92"><span uk-pagination-next="" class="uk-pagination-next uk-icon"><svg width="7" height="12" viewBox="0 0 7 12" xmlns="http://www.w3.org/2000/svg" ratio="1"><polyline fill="none" stroke="#000" stroke-width="1.2" points="1 1 6 6 1 11"></polyline></svg></span></a></li-->
        </ul>

    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Shadow\Documents\foxwayn\resources\views/themes/tallstack/blog/index.blade.php ENDPATH**/ ?>