<?php $__env->startSection('content'); ?>

    <div class="max-w-4xl px-5 mx-auto mt-10 lg:px-0">
        <a href="<?php echo e(route('wave.blog')); ?>" class="flex items-center mb-6 font-mono text-sm font-bold cursor-pointer text-gray-500">
            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            back to the blog
        </a>
    </div>
    <article id="post-<?php echo e($post->id); ?>" class="max-w-4xl px-5 mx-auto prose prose-xl lg:prose-2xl lg:px-0">

        <meta property="name" content="<?php echo e($post->title); ?>">
        <meta property="author" typeof="Person" content="admin">
        <meta property="dateModified" content="<?php echo e(Carbon\Carbon::parse($post->updated_at)->toIso8601String()); ?>">
        <meta class="uk-margin-remove-adjacent" property="datePublished" content="<?php echo e(Carbon\Carbon::parse($post->created_at)->toIso8601String()); ?>">

        <div class="max-w-4xl mx-auto mt-6">

            <h1 class="flex flex-col leading-none">
                <span class="bg-clip-text bg-gradient-to-r from-yellow-400 via-red-400 to-purple-500 text-transparent"><?php echo e($post->title); ?></span>
                <span class="mt-0 mt-10 text-base font-normal">Written on <time datetime="<?php echo e(Carbon\Carbon::parse($post->created_at)->toIso8601String()); ?>"><?php echo e(Carbon\Carbon::parse($post->created_at)->toFormattedDateString()); ?></time>. Posted in <a href="<?php echo e(route('wave.blog.category', $post->category->slug)); ?>" rel="category"><?php echo e($post->category->name); ?></a>.</span>
            </h1>


        </div>

        <div class="relative">
            <img class="w-full h-auto rounded-lg" src="<?php echo e($post->image()); ?>" alt="<?php echo e($post->title); ?>" srcset="<?php echo e($post->image()); ?>">
        </div>

        <div class="max-w-4xl mx-auto">
            <?php echo $post->body; ?>

        </div>

    </article>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Shadow\Documents\foxwayn\resources\views/themes/tallstack/blog/post.blade.php ENDPATH**/ ?>