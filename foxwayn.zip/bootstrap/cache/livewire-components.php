<?php return array (
  'show-mentions' => 'App\\Http\\Livewire\\ShowMentions',
  'wave.deploy-to-do' => 'App\\Http\\Livewire\\Wave\\DeployToDo',
);