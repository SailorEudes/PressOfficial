# Support

Wave is meant to serve as a starter kit, that will save you hundreds of hours, which is used to quickly create your SAAS app. When your application continues to grow you may wish to extend you application beyond Wave's features. In the events that your features conflict with the core features, support may be limited.