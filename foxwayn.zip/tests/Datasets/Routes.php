<?php

dataset('routes', function () {
    return [
        '/admin/login',
        '/@admin',
        '/blog',
        '/blog/category-1',
        '/blog/category-1/best-ways-to-market-your-application',
        '/docs/welcome',
        '/login',
        '/password/reset',
        '/pricing',
        '/p/about',
    ];
});
